String AP_NAME = "Krushiler_Network_";
String AP_PASSWORD = "13371488";


const char* mqtt_broker = "broker.emqx.io";
const int mqtt_port = 1883;
String topic = "esp8266_Krushiler/command";

int WEB_SERVER_PORT = 80;